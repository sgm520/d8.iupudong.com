<?php

namespace app\web\controller;

use app\web\model\TixianModel;
use app\web\model\UserModel;
use cmf\controller\HomeBaseController;
use think\Model;

class UserController extends HomeBaseController{

    protected $userId,$user_name;
    public function initialize()
    {
        $this->userId = session("USER_ID");
        $this->user_name = session("USER_NAME");
        if (empty($this->userId)) {
            echo json_encode(["code"=>"404","state"=>0,"data"=>"请登录账号！"],JSON_UNESCAPED_UNICODE);
            die;
        }

        parent::initialize();
    }

    /**
     * 个人中心页面
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
    public function user(){
        $user = new UserModel();
        $u_data = $user
            ->where("id",$this->userId)
            ->field("tel,last_tel,income,tx,ktx,user_nickname")
            ->find();
        echo json_encode(["code"=>200,"data"=>$u_data],JSON_UNESCAPED_UNICODE);

    }

    /**
     * 提现页面
     */
    public function tx(){
        $user = new UserModel();
        $u_data = $user
            ->where("id",$this->userId)
            ->field("al_pay_name,al_pay_account")
            ->find();

        if(is_null($u_data['al_pay_name']) || is_null($u_data['al_pay_account'])){
            echo json_encode(['code'=>21,"data"=>"请绑定支付宝"],JSON_UNESCAPED_UNICODE);
        }else{
            $tx = $this->request->param("tx");
            $this->tx_validate($tx);
        }

    }

    /*
     * 判断是否可提现
     */
    public function tx_validate($tx){

        $user = new UserModel();
        $txModel = new TixianModel();
        $money = $user
            ->where("id",$this->userId)
            ->field("tx,ktx,income")
            ->find();

        if($money['ktx']>=$tx){
            $ins = [
                "money"=>$tx, //提现金额
                "tx_time" => time(), //提现时间
                "state" => "0", //未处理
                "user_id" => $this->userId,
                "user_login" => $this->user_name,
            ];
            $txModel
                ->save($ins);
            echo json_encode(["code"=>200,"data"=>"提现成功"],JSON_UNESCAPED_UNICODE);
        }else{
            echo json_encode(["code"=>"22","data"=>"可提现金额不足"],JSON_UNESCAPED_UNICODE);
        }

    }



}