<?php

namespace app\web\controller;

use app\web\model\UserModel;
use app\web\model\RoleUserModel;
use cmf\controller\HomeBaseController;

class LoginController extends HomeBaseController{

    public function initialize()
    {
            $adminId = session("USER_ID");
            if (empty($adminId)) {
                session("__LOGIN_BY_CMF_ADMIN_PW__", 1);//设置后台登录加密码
            }

        parent::initialize();
    }

    /**
     *登录页面
     */
    public function Login_authentication(){
        if (!$this->request->isPost()) {
            $this->error('非法登录!');
        }


        $loginAllowed = session("__LOGIN_BY_CMF_ADMIN_PW__");
        if (empty($loginAllowed)) {
            echo json_encode(['code'=>0,"data"=>"非法登录!"],JSON_UNESCAPED_UNICODE);
        }

        $name = $this->request->param("tel");
        if (empty($name)) {
            echo json_encode(['code'=>0,"data"=>lang('USERNAME_OR_EMAIL_EMPTY')],JSON_UNESCAPED_UNICODE);

        }

        $pass = $this->request->param("password");
        if (empty($pass)) {
            echo json_encode(['code'=>0,"data"=>lang('PASSWORD_REQUIRED')],JSON_UNESCAPED_UNICODE);
        }

        if (strpos($name, "@") > 0) {//邮箱登陆
            $where['user_email'] = $name;
        } else {
            $where['user_login'] = $name;
        }

        $result = UserModel::where($where)->find();

        if (!empty($result) && $result['user_type'] == 1) {
            if (cmf_compare_password($pass, $result['user_pass'])) {
                $groups = RoleUserModel::alias("a")
                    ->join('role b', 'a.role_id =b.id')
                    ->where(["user_id" => $result["id"], "status" => 1])
                    ->value("role_id");
                if ($result["id"] != 1 && (empty($groups) || empty($result['user_status']))) {
                    echo json_encode(['code'=>0,"data"=>lang('USE_DISABLED')],JSON_UNESCAPED_UNICODE);
                }
                //登入成功页面跳转
                session('USER_ID', $result["id"]);
                session('USER_NAME', $result["user_login"]);
                $data                    = [];
                $data['last_login_ip']   = get_client_ip(0, true);
                $data['last_login_time'] = time();
                $token                   = cmf_generate_user_token($result["id"], 'web');
                if (!empty($token)) {
                    session('token', $token);
                }
                UserModel::where('id', $result['id'])->update($data);
                cookie("admin_username", $name, 3600 * 24 * 30);
                session("__LOGIN_BY_CMF_ADMIN_PW__", null);
//                $this->success(lang('LOGIN_SUCCESS'), url("admin/Index/index"));
                echo json_encode(['code'=>200,"data"=>"登陆成功"],JSON_UNESCAPED_UNICODE);
            } else {
                echo json_encode(['code'=>0,"data"=>lang('PASSWORD_NOT_RIGHT')],JSON_UNESCAPED_UNICODE);

            }
        } else {
            echo json_encode(['code'=>0,"data"=>lang('USERNAME_NOT_EXIST')],JSON_UNESCAPED_UNICODE);
        }


    }

    /**
     *退出登录页面
     */

    public function logout(){
        session("USER_ID",null);
        echo json_encode(["code"=>200,"data"=>"退出成功"],JSON_UNESCAPED_UNICODE);
//        return redirect(url('/', [], false, true));
    }


}