<?php
namespace app\web\controller;


use app\web\model\UserModel;
use cmf\controller\HomeBaseController;

class RegisterController extends HomeBaseController{


    /**
     * 注册页面API
     */
    public function index(){
        $data = $this->request->param(["user_pass","user_login"]);
        $ud = [
          "user_login"  =>$data['user_login'],
          "user_pass" => cmf_password($data['user_pass'])
        ];
        $user = new UserModel();
        $user->save($ud);
        echo json_encode(["code"=>200,"data"=>"注册成功"],JSON_UNESCAPED_UNICODE);
//        $this->success("注册成功");
    }


}