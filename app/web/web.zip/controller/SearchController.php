<?php
namespace app\web\controller;

use cmf\controller\HomeBaseController;

class SearchController extends HomeBaseController{

    /*
     * 搜索API
     */
    public function search(){

    }


}