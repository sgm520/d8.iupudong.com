<?php
namespace app\web\model;

use think\Model;

class TixianModel extends Model{

    /**
     * 模型名称
     * @var string
     */
    protected $name = 'tixian';


}